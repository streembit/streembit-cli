﻿const res = require('app-module-path').addPath(__dirname);

module.exports = res;