﻿# Data directory

Use this readme file to ensure the data directory exists when the app is deployed.
